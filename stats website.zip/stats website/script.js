function getNumbers() {
    let input = document.getElementById("numbersInput").value;
    return input.split(",").map(num => Number(num.trim()));
}

function getMean(numbers) {
    return numbers.reduce((acc, val) => acc + val, 0) / numbers.length;
}

function calculateMedian() {
    let numbers = getNumbers().sort((a,b)=>a-b);
    let mid = Math.floor(numbers.length / 2);
    let median = numbers.length % 2 === 0 ? (numbers[mid-1]+numbers[mid])/2 : numbers[mid];
    showResult(median);
}

function calculateRange() {
    let numbers = getNumbers().sort((a,b)=>a-b);
    showResult(numbers[numbers.length-1] - numbers[0]);
}

function calculateVariance() {
    let numbers = getNumbers();
    let mean = getMean(numbers);
    let sumSqDiff = numbers.reduce((acc, val) => acc + (val - mean)**2, 0);
    showResult(sumSqDiff / numbers.length);
}

function calculate(type) {
    let numbers = getNumbers();
    let result;

    if(type === 'add') result = numbers.reduce((a,b)=>a+b,0);
    else if(type === 'subtract') result = numbers.slice(1).reduce((a,b)=>numbers[0]-b, numbers[0]);
    else if(type === 'multiply') result = numbers.reduce((a,b)=>a*b,1);
    else if(type === 'divide') {
        result = numbers[0];
        for(let i=1;i<numbers.length;i++){
            if(numbers[i]===0){ showResult("Cannot divide by 0 😭"); return; }
            result /= numbers[i];
        }
    }

    showResult(result);
}

function showResult(value) {
    document.getElementById("result").innerText = "Result: " + value;
}